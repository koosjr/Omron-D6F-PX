/* D6P library 
GPL license
written by LuNEx
*/

#include "D6P.h"
#include "Wire.h"


D6P::D6P(uint8_t type, int i2c_addr, float atm_pressure) {
  _type = type;
  _i2c_addr = i2c_addr;
  _atm_pressure = atm_pressure;
}

int D6P::initialize(void)
{
  //INITIALIZATION AFTER POWER UP
  Wire.begin();
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x0B);  
  Wire.write(0x00); 
  int x = Wire.endTransmission(); 
  return x;
}

float D6P::pressure(void)
{
  //MCU MODE
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x00);   
  Wire.write(0xD0);  // reg 0 - address register high byte 
//  Wire.write(0x51);  // reg 1 - address register low byte
  Wire.write(0x40);  // reg 1 - address register low byte
  Wire.write(0x18);  // reg 2  - serial control register - indicate # bytes among others (page 7 bottom)
  Wire.write(0x06);  // reg 3 - value to be written to SENS control register
  int x = Wire.endTransmission(); 

  delay(33);

  //WRITE
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x00);   
  Wire.write(0xD0);
  Wire.write(0x51);
  Wire.write(0x2C);
  x = Wire.endTransmission(); 
  
  //READ
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x07);
  x = Wire.endTransmission(); 

  Wire.requestFrom(_i2c_addr, 2);
  byte hibyte = Wire.read();
  byte lobyte = Wire.read();
  long raw = word( hibyte, lobyte);  
  //Serial.print("raw pressure:\t ");
  //Serial.println(raw); 
  
  // D6F-PH5050AD3 ==> rangeMode=500 ==> int rd_pressure =  ((raw - 1024) * rangeMode * 2 / 60000L) - rangeMode
  // D6F-PH0505AD3 ==> rangeMode=50  ==> int rd_pressure =  ((raw - 1024) * rangeMode * 2 / 60000L) - rangeMode
  // D6F-PH0025AD1 ==> rangeMode=250 ==> int rd_pressure=(raw - 1024) * rangeMode / 60000L
  
  int rangeMode = 0; // INITIALIZE VARIABLE
  float rd_pressure = 0; // INITIALIZE VARIABLE
  
  switch (_type) {
    case D6F_PH5050AD3:
      rangeMode=500;
      rd_pressure = (((raw - 1024) * rangeMode * 2 / 60000L) - rangeMode) * _atm_pressure / 100;
	  break;
    case D6F_PH0505AD3:
      rangeMode=50;
      rd_pressure = (((raw - 1024) * rangeMode * 2 / 60000L) - rangeMode) * _atm_pressure / 100;
	  break;
    case D6F_PH0025AD1:
      rangeMode=250;
      rd_pressure=((raw - 1024) * rangeMode / 60000L) * _atm_pressure / 100;
	  break;
    }
  
  return rd_pressure;
}

float D6P::temperature(void)
{
  //MCU MODE
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x00);   
  Wire.write(0xD0);  // reg 0 - address register high byte 
  // Wire.write(0x51);  // reg 1 - address register low byte
  Wire.write(0x40);  // reg 1 - address register low byte  
  Wire.write(0x18);  // reg 2  - serial control register - indicate # bytes among others (page 7 bottom)
  Wire.write(0x06);  // reg 3 - value to be written to SENS control register
  int x = Wire.endTransmission(); 

  delay(33);
  
  //WRITE
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x00);   
  Wire.write(0xD0);
  Wire.write(0x61);
  Wire.write(0x2C);
  x = Wire.endTransmission(); 
  
  //READ
  Wire.beginTransmission(_i2c_addr);
  Wire.write(0x07);
  x = Wire.endTransmission(); 

  Wire.requestFrom(_i2c_addr, 2);  
  byte hibyte = Wire.read();
  byte lobyte = Wire.read();
  long raw = word( hibyte, lobyte);  
  //Serial.print("raw temperature:\t ");
  //Serial.println(raw); 
  int temp = round((float)(raw - 10214) / 3.739);  // this is the temperature multiplied by 10...
  return (temp/10.0);             // ...and the function returs the float temperature with 0.1°C resolution
}