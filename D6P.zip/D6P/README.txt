Check that the D6P folder contains D6P.cpp and D6P.h. Place the D6P library folder in your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.

#include "D6P.h"

// Uncomment whatever type you're using!
//#define D6FTYPE D6F_PH5050AD3  
//#define D6FTYPE D6F_PH0505AD3   
//#define D6FTYPE D6F_PH0025AD1    

#define addrs 0x6C // I2C bus address
#define AtmPressure 100 // Atmosferic Pressure in kPa - to compensate for altitude.

int P;
int I;
float T;

// initialize the library instance
D6P sensor(D6FTYPE, addrs, AtmPressure);

void setup() {
  // Open serial communications   
  Serial.begin(9600);
  I=sensor.initialize(); // start wire connection  
}

void loop() {
  P=sensor.pressure();
  Serial.print("pressure:\t ");
  Serial.println(P);
  T=sensor.temperature();
  Serial.print("temperature:\t ");
  Serial.println(T);
  delay(1000); //delay for 30 seconds
}