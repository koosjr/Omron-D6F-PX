#ifndef D6P_H
#define D6P_H
#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

/* D6P library 
GPL license
written by LuNEx
*/

//Sensor type Defines
//*****************************//
	#define D6F_PH5050AD3 11
	#define D6F_PH0505AD3 22
	#define D6F_PH0025AD1 21
//*****************************//

class D6P {
 private:
  int _i2c_addr;
  uint8_t _type;
  float _atm_pressure;

 public:
  D6P(uint8_t type,int i2c_addr,float atm_pressure);
  int initialize(void);
  float pressure(void);
  float temperature(void);
};
#endif

